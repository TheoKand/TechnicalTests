﻿using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Paymentsense.Coding.Challenge.Api.Controllers;
using Paymentsense.Coding.Challenge.Api.Models;
using Paymentsense.Coding.Challenge.Api.Services;
using System;
using System.Collections.Generic;
using Xunit;

namespace Paymentsense.Coding.Challenge.Api.Tests.Controllers
{
    public class PaymentsenseCodingChallengeControllerTests
    {
        private Mock<ICountriesService> _countriesService;

        public PaymentsenseCodingChallengeControllerTests()
        {
            _countriesService = new Mock<ICountriesService>();
            _countriesService.Setup(s => s.GetAllAsync()).ReturnsAsync(
                new List<Country>()
                {
                    new Country
                    {
                         Name="Greece"
                    },
                    new Country
                    {
                        Name="United Kingdom"
                    }
                }
            );
            _countriesService.Setup(s => s.SearchByNameAsync("Greece")).ReturnsAsync(
                new List<Country>()
                {
                    new Country
                    {
                         Name="Greece"
                    }
                }
            );
        }

        [Fact]
        public void GetAll_ReturnsAllCountries()
        {
            //Arrange
            var controller = new PaymentsenseCodingChallengeController(_countriesService.Object);

            //Act
            var result = controller.GetAll().Result.Result as OkObjectResult;

            //Assert;
            result.StatusCode.Should().Be(StatusCodes.Status200OK);
            (result.Value as IEnumerable<Country>).Should().HaveCount(2);
        }

        [Fact]
        public void GetAll_OnError_ReturnsBadRequest()
        {
            //Arrange
            _countriesService.Setup(s => s.GetAllAsync()).Throws(new Exception("An error occured"));
            var controller = new PaymentsenseCodingChallengeController(_countriesService.Object);

            //Act
            var result = controller.GetAll().Result.Result as ObjectResult;

            //Assert
            result.StatusCode.Should().Be(StatusCodes.Status400BadRequest);
        }

        [Fact]
        public void SearchByName_ReturnsMatchedCountry()
        {
            //Arrange
            var controller = new PaymentsenseCodingChallengeController(_countriesService.Object);

            //Act
            var result = controller.SearchByName("Greece").Result.Result as OkObjectResult;

            //Assert
            result.StatusCode.Should().Be(StatusCodes.Status200OK);
            (result.Value as IEnumerable<Country>).Should().HaveCount(1);
        }

        [Fact]
        public void SearchByName_OnError_ReturnsBadRequest()
        {
            //Arrange
            _countriesService.Setup(s => s.SearchByNameAsync("Greece")).Throws(new Exception("An error occured"));
            var controller = new PaymentsenseCodingChallengeController(_countriesService.Object);

            //Act
            var result = controller.SearchByName("Greece").Result.Result as ObjectResult;

            //Assert
            result.StatusCode.Should().Be(StatusCodes.Status400BadRequest);
        }
    }
}
