﻿using Microsoft.AspNetCore.Mvc;
using Paymentsense.Coding.Challenge.Api.Models;
using Paymentsense.Coding.Challenge.Api.Services;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Paymentsense.Coding.Challenge.Api.Controllers
{
    [ApiController]
    public class PaymentsenseCodingChallengeController : ControllerBase
    {
        private readonly ICountriesService _countriesService;

        public PaymentsenseCodingChallengeController(ICountriesService countriesService)
        {
            _countriesService = countriesService;
        }

        [HttpGet]
        [Route("~/Countries/All")]
        public async Task<ActionResult<IEnumerable<Country>>> GetAll()
        {
            try
            {
                var result = await _countriesService.GetAllAsync();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return new BadRequestObjectResult(ex.Message);
            }
        }

        [HttpGet]
        [Route("~/Countries/SearchByName/{name}")]
        public async Task<ActionResult<IEnumerable<Country>>> SearchByName(string name)
        {
            try
            {
                var result = await _countriesService.SearchByNameAsync(name);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return new BadRequestObjectResult(ex.Message);
            }

        }
    }
}
