﻿using Newtonsoft.Json;

namespace Paymentsense.Coding.Challenge.Api.Models
{
    public class Language
    {
        [JsonProperty("iso639_1")] public string IsoCode { get; set; }

        public string Name { get; set; }
    }
}
