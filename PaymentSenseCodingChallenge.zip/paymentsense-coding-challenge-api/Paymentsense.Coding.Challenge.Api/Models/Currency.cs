﻿namespace Paymentsense.Coding.Challenge.Api.Models
{
    public class Currency
    {
        public string Code { get; set; }

        public string Name { get; set; }

        public string Symbol { get; set; }
    }
}
