﻿using Newtonsoft.Json;
using Paymentsense.Coding.Challenge.Api.Models;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace Paymentsense.Coding.Challenge.Api.Services
{
    public class CountriesService : ICountriesService
    {
        private const string BaseUri = "https://restcountries.eu";

        private IHttpClientFactory _httpClientFactory;


        public CountriesService(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        protected async Task<T> BaseGetRequest<T>(string uri)
        {
            using var httpClient = _httpClientFactory.CreateClient();
            var response = await httpClient.GetAsync(uri).ConfigureAwait(false);
            response.EnsureSuccessStatusCode();

            var stringResponse = await response.Content.ReadAsStringAsync();
            var result = JsonConvert.DeserializeObject<T>(stringResponse);
            return result;
        }

        public async Task<IEnumerable<Country>> GetAllAsync()
        {
            var requestUri = $"{BaseUri}/rest/v2/all";
            return await BaseGetRequest<IEnumerable<Country>>(requestUri);
        }

        public async Task<IEnumerable<Country>> SearchByNameAsync(string name)
        {
            var requestUri = $"{BaseUri}/rest/v2/name/{name}";
            return await BaseGetRequest<IEnumerable<Country>>(requestUri);
        }
    }
}
