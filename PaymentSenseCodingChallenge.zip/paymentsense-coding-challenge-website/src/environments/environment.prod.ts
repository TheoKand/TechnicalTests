export const environment = {
  apiUrl: 'https://paymentsense/codingchallenge',  
  production: true
};
