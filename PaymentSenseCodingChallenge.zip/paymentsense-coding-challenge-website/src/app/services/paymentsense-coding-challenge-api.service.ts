import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { HttpClient } from "@angular/common/http";
import { environment } from "src/environments/environment";
import { Country } from "../models";

@Injectable({
  providedIn: "root",
})
export class PaymentsenseCodingChallengeApiService {
  constructor(private httpClient: HttpClient) {}

  public getHealth(): Observable<string> {
    const apiUrl = environment.apiUrl;
    return this.httpClient.get(`${apiUrl}/health`, { responseType: "text" });
  }

  public getAllCountries(): Observable<Country[]> {
    const apiUrl = environment.apiUrl;
    var result = this.httpClient.get<Country[]>(`${apiUrl}/Countries/All`, {
      responseType: "json",
    });
    return result;
  }

  public searchByName(name: string): Observable<Country[]> {
    const apiUrl = environment.apiUrl;
    var result = this.httpClient.get<Country[]>(
      `${apiUrl}/Countries/SearchByName/${name}`,
      { responseType: "json" }
    );
    return result;
  }
}
