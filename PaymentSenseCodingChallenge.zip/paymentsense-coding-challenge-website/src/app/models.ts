export class Currency {
  code: string;
  name: string;
  symbol: string;
}

export class Language {
  isoCode: string;
  name: string;
}

export class Country {
  name: string;
  flag: string;
  population: number;
  timezones: string[];
  currencies: Currency[];
  languages: Language[];
  capital: string;
}
