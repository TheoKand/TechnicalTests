import { Component } from "@angular/core";
import { PaymentsenseCodingChallengeApiService } from "./services";
import { Country } from "./models";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"],
})
export class AppComponent {
  public title = "Paymentsense Coding Challenge!";

  public apiCountries: Country[];
  public localCountries: Country[] = [];

  public page: number = 0;
  public pageSize: number = 10;
  public selectedCountry: Country;
  public searchCriteria: string = "";
  public showAddCountry: boolean;

  public newCountry: Country = new Country();

  getAllCountries(): Country[] {
    return this.localCountries
      .filter(
        (c) => !this.searchCriteria || c.name.includes(this.searchCriteria)
      )
      .concat(this.apiCountries);
  }

  getCountriesLength(): number {
    return this.getAllCountries() ? this.getAllCountries().length : 0;
  }

  shouldShowCountry(): boolean {
    return this.selectedCountry !== undefined && this.selectedCountry != null;
  }

  selectCountry(country: Country) {
    this.selectedCountry = country;
  }

  hideCountry() {
    this.selectedCountry = undefined;
  }

  updateSearch(input: string) {
    this.searchCriteria = input;
    this.search();
  }

  selectedCountryCurrencies(): string {
    return this.selectedCountry.currencies
      .map((c) => `${c.code} ${c.name} ${c.symbol}`)
      .join(",");
  }

  selectedCountryLanguages(): string {
    return this.selectedCountry.languages
      .map((c) => `${c.isoCode} ${c.name}`)
      .join(",");
  }

  selectedCountryTimezones(): string {
    return this.selectedCountry.timezones.join(",");
  }

  onAddCountry() {
    this.showAddCountry = true;
  }

  onSaveCountry() {
    console.log(this.newCountry);
    this.localCountries.push(this.newCountry);
    this.newCountry = new Country();
    this.showAddCountry = false;
  }

  search() {
    if (this.searchCriteria) {
      this.paymentsenseCodingChallengeApiService
        .searchByName(this.searchCriteria)
        .subscribe(
          (countries: Country[]) => {
            this.apiCountries = countries;
          },
          () => {
            this.apiCountries = [];
          }
        );
    } else {
      this.paymentsenseCodingChallengeApiService
        .getAllCountries()
        .subscribe((countries: Country[]) => {
          this.apiCountries = countries;
        });
    }
  }

  constructor(
    private paymentsenseCodingChallengeApiService: PaymentsenseCodingChallengeApiService
  ) {
    this.search();
  }
}
